All files in the root of your zip, do not create any folder in the zip archive.
Html file that will be loaded is "index.html".
In index.html you can include javascript files, images and css files.
